import requests
from flask import Flask, jsonify, request

from sealpir import encrypt_query, perform_privacy_computation

app = Flask(__name__)

@app.route('/')
def home():
    return 'Flask App is running!'

@app.route('/privacy_computation', methods=['POST'])
def route_privacy_computation():
    data = request.get_json()
    query = data.get('query')
    data_url = data.get('data_url')  # Use data_url instead of data_path

    encrypted_query = encrypt_query(query)

    # Make an HTTP request to the data holder's server to get the result
    data_holder_url = 'http://data-holder-server:5000/perform_privacy_computation'
    response = requests.post(data_holder_url, json={'encrypted_query': encrypted_query, 'data_url': data_url})

    # Extract the result from the response
    result = response.json().get('result')

    return jsonify({'result': result})

@app.route('/another_operation', methods=['POST'])
def route_another_operation():
    # Add another route for a different operation
    # This could be a separate functionality you want to perform
    data = request.get_json()
    # Extract data and perform the desired operation

    return jsonify({'result': 'Another operation result'})

if __name__ == '__main__':
    app.run(debug=True)
