import traceback  # Import traceback for error logging

from flask import Flask, jsonify, request

from sealpir import load_data, perform_privacy_computation

data_holder_app = Flask(__name__)

@data_holder_app.route('/compute_privacy_task', methods=['POST'])
def compute_privacy_task_endpoint():
    try:
        data = request.get_json()
        encrypted_query = data.get('encrypted_query')
        data_url = data.get('data_url')

        # Load data securely
        loaded_data = load_data(data_url)

        # Perform privacy computation
        result = perform_privacy_computation(encrypted_query, loaded_data)

        return jsonify({'result': result})

    except Exception as e:
        # Log the exception traceback for debugging purposes
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500  # Return a 500 Internal Server Error

if __name__ == '__main__':
    data_holder_app.run(host='0.0.0.0', port=5001, debug=True)
