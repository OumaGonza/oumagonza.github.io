import math
import random
import turtle


class MastermindGUI:
    colors = ["red", "blue", "green", "yellow", "purple", "black"]

    def __init__(self, master):
        self.master = master
        self.master.title("cs5001 Mastermind code Game")

        # Create frames for the game grid and leaderboard
        self.create_widgets()

    def create_widgets(self):
        # Left frame for the game grid
        self.left_frame = turtle.TurtleScreen(turtle.Screen())
        self.left_frame.title("cs5001 Mastermind code Game")
        self.left_frame.bgcolor("white")

        self.hexagons = []
        for row in range(10):
            hexagon_row = []
            for col in range(4):
                hexagon = HexagonCanvas(self.left_frame, row, col)
                hexagon.penup()
                hexagon.goto(col * 40, -row * 40)
                hexagon.pendown()
                hexagon_row.append(hexagon)
            self.hexagons.append(hexagon_row)

        # Right frame for the leaderboard
        self.right_frame = turtle.TurtleScreen(turtle.Screen())
        self.right_frame.title("Leaderboard")
        self.right_frame.bgcolor("white")

        # Initialize leaderboard
        self.leaderboard_label = turtle.Turtle()
        self.leaderboard_label.hideturtle()
        self.leaderboard_label.penup()
        self.leaderboard_label.color("skyblue")
        self.leaderboard_label.goto(0, 150)
        self.leaderboard_label.write("Leaders", align="center", font=("Helvetica", 14, "bold"))

        # Add leaderboard entries (for demonstration purposes)
        self.add_leaderboard_entry("Keith", 3)
        #self.add_leaderboard_entry("John", 5)

    def add_leaderboard_entry(self, player_name, score):
        entry_label = turtle.Turtle()
        entry_label.hideturtle()
        entry_label.penup()
        entry_label.color("skyblue")
        entry_label.goto(0, 120 - 30 * len(self.right_frame.turtles()))
        entry_label.write(f"{score}: {player_name}", align="center", font=("Helvetica", 12))

class HexagonCanvas(turtle.Turtle):
    def __init__(self, master, row, col, **kwargs):
        turtle.Turtle.__init__(self, **kwargs)
        self.row = row
        self.col = col
        self.color = ""
        self.draw_hexagon()

    def draw_hexagon(self):
        hexagon_points = self.calculate_hexagon_points()
        self.penup()
        self.goto(self.col * 40, -self.row * 40)
        self.pendown()
        self.begin_fill()
        self.color(self.color)
        for _ in range(6):
            self.forward(30)
            self.right(60)
        self.end_fill()

    def calculate_hexagon_points(self):
        center_x, center_y = self.position()
        radius = 15

        points = []
        for i in range(6):
            angle_rad = math.radians(60 * i)
            x = center_x + radius * math.cos(angle_rad)
            y = center_y + radius * math.sin(angle_rad)
            points.extend([x, y])

        return points

    def color_clicked(self, x, y):
        self.color = random.choice(MastermindGUI.colors)
        self.clear()
        self.draw_hexagon()

if __name__ == "__main__":
    root = turtle.Screen()
    game = MastermindGUI(root)
    root.mainloop()
