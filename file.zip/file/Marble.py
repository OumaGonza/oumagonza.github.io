import turtle


class Marble:
    def __init__(self, x, y, size=20, color="black"):
        self.pen = turtle.Turtle()
        self.pen.speed(0)
        self.pen.hideturtle()

        self.color = color
        self.position = Point(x, y)
        self.visible = False
        self.is_empty = True
        self.size = size

    def draw_empty(self):
        self.pen.penup()
        self.pen.goto(self.position.x, self.position.y - self.size // 2)
        self.pen.pendown()
        self.pen.color("black")
        self.pen.circle(self.size)

    def set_color(self, color):
        self.color = color

    def get_color(self):
        return self.color

    def erase(self):
        self.pen.clear()

    def is_clicked(self, x, y):
        distance = Point(x, y).delta_x(self.position) ** 2 + Point(x, y).delta_y(self.position) ** 2
        return distance <= self.size ** 2
