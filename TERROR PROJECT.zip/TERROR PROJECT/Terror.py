#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install pandas')


# In[2]:


get_ipython().system('pip install scikit-learn')


# In[3]:


import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


# In[4]:


df=pd.read_excel("TERORI1.xlsx")
X = df.drop(columns=['country'])
y =df['country']


# In[5]:


kd =pd.read_csv("globalterrorismdb1.csv" , encoding = "ISO-8859-1")
kd


# In[7]:


model = DecisionTreeClassifier()
model.fit(X, y)
predictions = model.predict([[2023,4], [2024,7]])
predictions


# In[13]:


from sklearn.metrics import accuracy_score
y_pred = [0, 2, 1, 3]
y_true = [0, 1, 2, 3]
accuracy_score(y_true, y_pred)
0.000
# The output will give out the number of correct predictions from all predictions that will be made.
# The code displays the accuracy score of the model.


# In[ ]:




